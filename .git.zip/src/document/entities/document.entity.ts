export class Document {}
